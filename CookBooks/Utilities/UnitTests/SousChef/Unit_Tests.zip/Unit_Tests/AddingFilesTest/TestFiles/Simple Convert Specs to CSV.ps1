﻿param($variables)
# GET Excel Data without Excel  -  https://blogs.technet.microsoft.com/pstips/2014/06/02/get-excel-data-without-excel/#comment-1055
# Download ACE.OLEDB provider   -  https://www.microsoft.com/en-us/download/confirmation.aspx?id=13255
$currentDirectory = $variables.CurrentKitchen
$excelBookName = $variables.ExcelBookName


<#
$currentDirectory = 'C:\Users\rboley\Desktop\Sous Chef\DefaultKitchen'
$excelBookName = 'Kaleida RCPA - Back End Workflow Specv7_4.9.xlsx'
#>


#$currentDirectory > "C:\Users\rboley\Desktop\Sous Chef\DefaultKitchen\FAST - TRAC Worklists\test.txt" 


$excelFile = Get-ChildItem $currentDirectory -Filter "*$excelBookName*" -Recurse
$csvFolder = Get-ChildItem $currentDirectory -Recurse -Directory -Filter "*CSVs"
$FolderBrowser =  $csvFolder.FullName

function Get-ExcelData ($path, $outputFolder) {

    $Provider = 'Microsoft.ACE.OLEDB.12.0'
    $ExtendedProperties = 'Excel 12.0;HDR=YES'
            
    # Build the connection string and connection object
    $ConnectionString = 'Provider={0};Data Source={1};Extended Properties="{2}"' -f $Provider, $Path, $ExtendedProperties
    $Connection = New-Object System.Data.OleDb.OleDbConnection $ConnectionString

    try {
        # Open the connection to the file, and fill the datatable
        $Connection.Open()
        $tables = $Connection.GetSchema("tables").TableName
        
            
        foreach ($table in $connection.GetSchema("tables")) {
            Write-Host $table.TABLE_NAME
            if($table.TABLE_NAME -notmatch '\$')
            {
                continue
            }
            $Query = 'SELECT * FROM [{0}]' -f $table.TABLE_NAME 
                
            $scrubName = $table.TABLE_NAME -replace '\$', ""
            $scrubName = $scrubName -replace ' ', ""
            $scrubName = $scrubName -replace "'", ""
            $scrubName = "$scrubName.csv"

            $Adapter = New-Object -TypeName System.Data.OleDb.OleDbDataAdapter $Query, $Connection
            $DataTable = New-Object System.Data.DataTable
            $Adapter.Fill($DataTable) | Out-Null

            $columnsToDelete = @()
            foreach ($column in $DataTable.Columns)
            {
                if(($column -match 'F[0-9].*') -or ($column -eq ''))
                {
                    #$DataTable.Columns.Remove($column)
                    $columnsToDelete += $column
                }
            }

            foreach ($column in $columnsToDelete)
            {
                $DataTable.Columns.Remove($column)
            }

            Write-Host "Datatable:$($scrubname) has:$($datatable.rows.Count) Rows"
            $newname = Join-Path $outputfolder $scrubName
            if($datatable.rows.Count -gt 1)
            {
                $DataTable | Export-csv -Path $newname -NoTypeInformation -Delimiter "," -force  
            }
        }
        #>

    }
    catch {
        # something went wrong 🙁
        Write-Error $_.Exception.Message
    }
    finally {
        # Close the connection
        if ($Connection.State -eq 'Open') {
            $Connection.Close()
        }
    }

    # Return the results as an array
    return ,$DataTable
}


$output = Get-ExcelData -Path $excelFile.FullName -OutputFolder $FolderBrowser