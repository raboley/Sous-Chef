USE $(TRACDatabase)
/****** Object:  StoredProcedure [SPEC].[QUIC_Billhold_Assignments]    Script Date: 3/20/2018 3:30:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('[SPEC].[QUIC_Billhold_Assignments]') IS NOT NULL
    BEGIN
    DROP PROCEDURE [SPEC].[QUIC_Billhold_Assignments] ;
    PRINT '<<< DROPPED PROCEDURE [SPEC].[QUIC_Billhold_Assignments]  >>>';
END;
GO


CREATE PROCEDURE [SPEC].[QUIC_Billhold_Assignments] 

/*       COPYRIGHT (c) Huron Healthcare    WRITTEN: Russell Boley   PURPOSE:   Update Or insert Facility Codes   
ASSUMPTIONS:  Files have already been staged <-- not smart enough to know this.    
CHANGE LOG:  2013-01-21: Created      ~CUSTOM~ 		
Initials Date - Adapted for [Client] [HIS] KeyAR Import Master <- Replace with your client and HIS 
SAMPLE CALL:    EXEC [SPEC].[Shared_Facility_Codes] 1, @@SERVERNAME, 1; */
(
	@location VARCHAR(8000) =  NULL,
	@TicketNumber VARCHAR(100) =  NULL,
	@debug bit=0
)

AS
BEGIN
  SET NOCOUNT ON;
  SET QUOTED_IDENTIFIER ON;

IF OBJECT_ID('tempdb..#WhileList') IS NOT NULL DROP TABLE #WhileList
IF OBJECT_ID('tempdb..#GRID') IS NOT NULL DROP TABLE #GRID

DECLARE @i int = 1
----- [CHG1] -----
DECLARE @Variable1 VARCHAR(100)
DECLARE @Variable2 VARCHAR(100)
DECLARE @Variable3 VARCHAR(100)
DECLARE @Variable4 VARCHAR(100)
DECLARE @variable5 VARCHAR(MAX)
DECLARE @variable6 VARCHAR(100)
DECLARE @variable7 VARCHAR(MAX)
DECLARE @variable8 VARCHAR(100)
DECLARE @PK varchar(20)
DECLARE @PKAssignments int
DECLARE @errors TABLE (MinorCode varchar(50),MajorCode varchar(50),MinorDescription Varchar(50),ErrorMessage VARCHAR(MAX))
DECLARE @PKGrid varchar(20)
DECLARE @operator varchar (50)
DECLARE @PKQUIC_Billholds INT
CREATE TABLE #Grid (PK varchar(20),Variable varchar(50),Operator VARCHAR(50),Value VARCHAR(999))
CREATE TABLE #WhileList (id int IDENTITY(1,1) ,Variable1 varchar(100),Variable2 VARCHAR(100),Variable3 VARCHAR(100),Variable4 VARCHAR(100),Variable5 VARCHAR(999),variable6 VARCHAR(100),variable7 varchar(MAX),variable8 VARCHAR(100))

DECLARE @count int = 0


INSERT INTO #WhileList(Variable1,Variable2,Variable3,Variable4,Variable5)
SELECT DISTINCT
	-- [CHG2] Add Columns here
	BillholdExecutionOrder --variable1
	,DeficiencyCode--variable2
	,BillholdVariable--variable3
	,BillholdOperator --variable4
	,BillholdValue --variable5
	
	
	-- [CHG2] end of adding columns
FROM spec.SPEC_QUIC_Billholds
WHERE BillholdVariable NOT IN ('NULL','')
and(
	( @ticketnumber is not null and ticket =@TicketNumber)
	OR 
	( @ticketnumber is null)
	)
BEGIN TRAN
----------------WHILE LOOP to enumerate through every billhold------------------------
WHILE (@i <= (SELECT COUNT(*) FROM #WhileList)) 
BEGIN 


SET @Variable1 = (SELECT Variable1 FROM #WhileList WHERE id = @i)
SET @Variable2 = (SELECT variable2 FROM #WhileList WHERE id = @i)
SET @Variable3 = (SELECT Variable3 FROM #WhileList WHERE id = @i)
SET @Variable4 = (SELECT variable4 FROM #WhileList WHERE id = @i)
SET @variable5 = (SELECT variable5 FROM #WhileList WHERE id = @i)
SET @variable6 = (SELECT variable6 FROM #WhileList WHERE id = @i)
SET @variable7 = (SELECT variable7 FROM #WhileList WHERE id = @i)
SET @variable8 = (SELECT variable8 FROM #WhileList WHERE id = @i)


------- [CHG3] GET THE assignments PK for updates.-------
---- change this to pull the PK of the assignments needed for determining updates
SET @PKAssignments = (
	SELECT PKQUIC_BillholdAssignments FROM QUIC_BillholdAssignments bha
		JOIN quic_billholds bh ON bha.FKQUIC_Billholds=bh.PKQUIC_Billholds
	WHERE bh.BillholdExecutionOrder= @Variable1
	and bha.BillholdVariable=@Variable3
	)
SET @operator = (Case 
					WHEN @Variable4='=' THEN '=  (Equal To)'
					WHEN @Variable4='<>' THEN '<>  (Not Equal To)'
					WHEN @Variable4='IN' THEN 'IN  (Including)'
					WHEN @Variable4='NOT IN' THEN 'NOT IN  (NOT Including)'
					END
				)


SET @PKQUIC_Billholds =
(
	SELECT PKQUIC_Billholds from QUIC_Billholds where BillholdExecutionOrder=@Variable1
)
	--PRINT 'PKQUIC_Billholds:'+cast(@PKQUIC_Billholds as VARCHAR)+', '+'PKAssignments:'+cast(@PKAssignments as VARCHAR)+', '+'ExecOrder:'+@Variable1+', '+'DefCode:'+@Variable2+', '+'BHVar:'+@Variable3+', '+'BHOp:'+@Variable4+', '+'BHValue:'+@Variable5
-- [CHG4] GET THE PK For the grid if needing to update

INSERT INTO #Grid (PK,Variable,Operator,Value) 
exec dbo.spf_QUICBillholdAssignments_HISBillholdGrid_FillGrid @PKQUIC_Billholds

BEGIN
	SET @PKGRID = (SELECT PK FROM #Grid WHERE Variable = @Variable3 AND Operator = @Variable4)
END
----  Do stuff ----
--=========================================================================

--PRINT ''
--PRINT @variable1 +' | ' + @variable2 +' | '+ @variable3 +' | '+ @operator +' | '+ @variable5 +' | '


--- -- [CHG5] edit this to return whether or not something is valid. like criteria variable or something
IF EXISTS (SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.columns WHERE TABLE_NAME='QUIC_BillholdStaging' and COLUMN_NAME =  @Variable3)
	BEGIN
	IF NOT EXISTS(SELECT PKQUIC_Billholds FROM QUIC_Billholds as B
		WHERE B.BillholdExecutionOrder = @Variable1)
		BEGIN
		--PRINT 'INSERTING into Billhold Assignments'

		IF (@debug=1)
			BEGIN
			 PRINT 'exec dbo.spf_QUICBillholdAssignments_Insert 1,'''+@location+''','''+@Variable1+''','''+@variable2+''',null,null,null'
			END

		IF (@debug=0)
			BEGIN
			 exec dbo.spf_QUICBillholdAssignments_Insert 1,@location,@Variable1,@variable2,null,null,null
			END
		---- [CHG6] change this to be the correct insert sproc if something needs to be inserted to assignmetns
		
		----------- change this to pull the PK of the assignments needed for determining updates
			SET @PKAssignments = (
			SELECT PKQUIC_BillholdAssignments FROM QUIC_BillholdAssignments bha
			JOIN quic_billholds bh ON bha.FKQUIC_Billholds=bh.PKQUIC_Billholds
			WHERE bh.BillholdExecutionOrder= @Variable1
			and BillholdVariable=@variable3
			)

			SET @PKQUIC_Billholds =
			(
				SELECT PKQUIC_Billholds from QUIC_Billholds where BillholdExecutionOrder=@Variable1
				
			)
		
		-----------
		END
		ELSE
		BEGIN
			IF (@debug=1)
				BEGIN
				 PRINT 'exec dbo.spf_QUICBillholdAssignments_Update 1,'''+@location+''','+ cast(@PKQUIC_Billholds as varchar)+','''+@Variable1+''','''+@variable2+''',null,null,null'
				END
			IF (@debug=0)
				BEGIN
				 exec dbo.spf_QUICBillholdAssignments_Update 1,@location,@PKQUIC_Billholds,@Variable1,@variable2,null,null,null
				END
			
		END
	
	

	IF NOT EXISTS(SELECT PKQUIC_BillholdAssignments FROM QUIC_BillholdAssignments bha
		JOIN quic_billholds bh ON bha.FKQUIC_Billholds=bh.PKQUIC_Billholds
	WHERE bh.BillholdExecutionOrder= @Variable1
	and bha.BillholdVariable=@Variable3)
	--- checking to see if code already exists
		BEGIN
			IF (@debug=1)
				BEGIN
				 PRINT 'exec dbo.spf_QUICBillholdAssignments_HISBillholdGrid_InsertGrid 1,'''+@location+''','+ cast(@PKQUIC_Billholds as varchar)+','''+@operator+''','''+@Variable3+''','''+@variable5+''''
				END
			IF (@debug=0)
				BEGIN
				 exec dbo.spf_QUICBillholdAssignments_HISBillholdGrid_InsertGrid 1,@location,@PKQUIC_Billholds,@variable3,@operator,@variable5
				END
			
			
			
			---- [CHG8] change this to be correct sproc for inserting grids
			
			

		END
	ELSE
		BEGIN
			IF (@debug=1)
				BEGIN
				 PRINT 'exec dbo.spf_QUICBillholdAssignments_HISBillholdGrid_UpdateGrid 1,'''+@location+''','+ cast(@PKAssignments as varchar)+','''+@operator+''','''+@Variable3+''','''+@variable5+''''
				END
			IF (@debug=0)
				BEGIN
				 ---- [CHG8] change this to be correct sproc for inserting grids
			exec dbo.spf_QUICBillholdAssignments_HISBillholdGrid_UpdateGrid 1,@location,@PKAssignments,@variable3,@operator,@variable5
				END
			
			
		END
	END
	ELSE
	BEGIN
	INSERT INTO @errors (MinorCode,MinorDescription,MajorCode,ErrorMessage)
		SELECT @Variable1,@Variable2,@variable3,'ERROR variable ' + @Variable3 + ' Does not exist.. so deficiency code ' + @variable2 + ' Assignments Cannot be created or updated'
	END
--=========================================================================
	--------- end of things to do ---------------------------------------------------------------------------------------------------

	-- This should be last and set the id +1 so it does the next row
	SET @i = (@i + 1)
	TRUNCATE TABLE #Grid


END 
----------------------------------------
--COMMIT

SELECT * FROM @errors

SELECT TOP 100 PERCENT
QDC.DeficiencyCode,
ISNULL(QDC.DeficiencyDescription,'') AS DeficiencyDescription,
AREA.AreaCode,
QDC.DeficiencyPriority,
QSRC.SourceCode,
QDC.DelinquentDays,
QDC.IsInfoOnly,
QDC.IsDisabled,
ISNULL(QDC.DeficiencyComments,'') AS DeficiencyComments,
BHA.BillholdVariable,
BHA.BillholdOperator,
BHA.BillholdValue,
BH.BillholdExecutionOrder,
BHD.BillholdDeficiencyOrder
FROM
QUIC_DeficiencyCodes QDC
LEFT JOIN Shared_Areas AREA
ON QDC.FKShared_Areas = AREA.PKShared_Areas
LEFT JOIN QUIC_Sources QSRC
ON QDC.FKQUIC_Sources = QSRC.PKQUIC_Sources
INNER JOIN QUIC_BillholdDeficiencies BHD
INNER JOIN QUIC_Billholds BH
INNER JOIN QUIC_BillholdAssignments BHA
ON BH.PKQUIC_Billholds = BHA.FKQUIC_Billholds
ON BHD.FKQUIC_Billholds = BH.PKQUIC_Billholds
ON BHD.FKQUIC_DeficiencyCodes = QDC.PKQUIC_DeficiencyCodes
where bha.location=@location or bhd.Location=@location or bh.Location=@location
ORDER BY QDC.DeficiencyCode, BillholdExecutionOrder

COMMIT

END;



/*select bha.*,bh.*,bhd.*,dc.* from QUIC_BillholdAssignments bha
join quic_billholds bh on bh.PKQUIC_Billholds=bha.FKQUIC_Billholds
join QUIC_BillholdDeficiencies bhd on bhd.FKQUIC_Billholds=bh.PKQUIC_Billholds
join QUIC_DeficiencyCodes dc on dc.PKQUIC_DeficiencyCodes=bhd.FKQUIC_DeficiencyCodes
*/



