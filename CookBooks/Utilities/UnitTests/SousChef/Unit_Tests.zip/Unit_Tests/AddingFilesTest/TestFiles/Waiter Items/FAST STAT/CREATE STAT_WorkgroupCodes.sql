USE $(TRACDatabase)
GO

/****** Object:  StoredProcedure [spec].[STAT_WorkGroup_Codes]    Script Date: 4/4/2018 8:08:26 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('[spec].[STAT_WorkGroup_Codes]') IS NOT NULL
    BEGIN
    DROP PROCEDURE [spec].[STAT_WorkGroup_Codes]  ;
    PRINT '<<< DROPPED PROCEDURE [spec].[STAT_WorkGroup_Codes]   >>>';
END;
GO


CREATE PROCEDURE [spec].[STAT_WorkGroup_Codes] 
/*       COPYRIGHT (c) Huron Healthcare    WRITTEN: Russell Boley   PURPOSE:   Update Or insert Facility Codes   
ASSUMPTIONS:  Files have already been staged <-- not smart enough to know this.    
CHANGE LOG:  2013-01-21: Created      ~CUSTOM~ 		
Initials Date - Adapted for [Client] [HIS] KeyAR Import Master <- Replace with your client and HIS 
SAMPLE CALL:    EXEC [SPEC].[Shared_Facility_Codes] 1, @@SERVERNAME, 1; */
(
	@location VARCHAR(8000)= NULL,
	@CaseNumber VARCHAR(100)= NULL
)

AS
BEGIN
  SET NOCOUNT ON;
  SET QUOTED_IDENTIFIER ON;

IF OBJECT_ID('tempdb..#WhileList') IS NOT NULL DROP TABLE #WhileList
IF OBJECT_ID('tempdb..#GRID') IS NOT NULL DROP TABLE #GRID

DECLARE @i int = 1
----- [CHG1] -----
--- Generic Variables pulled from the specs
DECLARE @Variable1 VARCHAR(100)
DECLARE @Variable2 VARCHAR(100)
DECLARE @Variable3 VARCHAR(100)
DECLARE @Variable4 VARCHAR(100)
DECLARE @variable5 VARCHAR(100)
DECLARE @variable6 VARCHAR(100)
DECLARE @variable7 VARCHAR(100)
DECLARE @variable8 VARCHAR(100)

--- Specific calculated Variables
DECLARE @PK varchar(20)
DECLARE @errors TABLE (errorType varchar(100),errorMessage varchar(MAX),shouldRollback Int)
DECLARE @errorMessage varchar(MAX)
DECLARE @Representative varchar(100)
DECLARE @RawStatement VARCHAR(MAX) = 'DECLARE @PK varchar(20)'

--- Specific calculated Variables
DECLARE @PKAccessCode varchar (50)
DECLARE @workgroupcode varchar(100)

--- CREATING temporary tables 
CREATE TABLE #Grid (PK varchar(20),Variable varchar(50),Operator VARCHAR(50),Value VARCHAR(999))
CREATE TABLE #WhileList (id int IDENTITY(1,1),Variable1 varchar(100),Variable2 VARCHAR(100),Variable3 VARCHAR(100),Variable4 VARCHAR(100),Variable5 VARCHAR(100),Variable6 VARCHAR(100),Variable7 VARCHAR(999),Variable8 VARCHAR(100))

--- Inserting into the while loop, this select statement is what actually gets put in.
INSERT INTO #WhileList(Variable1,Variable2,Variable3,Variable4,Variable5,Variable6,Variable7,Variable8)
SELECT DISTINCT
	-- [CHG2] Add Columns here
	NULL --variable1
	,[Workgroup Code]--variable2
	,[Workgroup Description]--variable3
	,[Reporting Area Code] --variable4
	,NULL --variable5
	,NULL --variable 6
	,NULL --variable 7
	,Change --variable 8
	-- [CHG2] end of adding columns

FROM spec.SPEC_STAT_Workgroup_Specs
WHERE [Workgroup Code] <> ''
AND ISNULL(@caseNumber,CaseNumber) =  CaseNumber --- Adding to create a ticket number filter to only run records for the ticket number.

BEGIN TRAN
PRINT @rawstatement
----------------WHILE LOOP to enumerate through every row------------------------
WHILE (@i <= (SELECT COUNT(*) FROM #WhileList)) 
BEGIN 


SET @Variable1 = (SELECT Variable1 FROM #WhileList WHERE id = @i)
SET @Variable2 = (SELECT variable2 FROM #WhileList WHERE id = @i)
SET @Variable3 = (SELECT Variable3 FROM #WhileList WHERE id = @i)
SET @Variable4 = (SELECT variable4 FROM #WhileList WHERE id = @i)
SET @variable5 = (SELECT variable5 FROM #WhileList WHERE id = @i)
SET @variable6 = (SELECT variable6 FROM #WhileList WHERE id = @i)
SET @variable7 = (SELECT variable7 FROM #WhileList WHERE id = @i)
SET @variable8 = (SELECT variable8 FROM #WhileList WHERE id = @i)

------- [CHG3] GET THE assignments PK for updates.-------
---- change this to pull the PK of the assignments needed for determining updates

SET @PK = (SELECT PKShared_Workgroups FROM Shared_Workgroups WHERE WorkgroupCode = @Variable2)
----  Do stuff ----
--=========================================================================
--- -- [CHG5] edit this to return whether or not something is valid. like criteria variable or something
IF EXISTS (SELECT 1 FROM Shared_Areas where AreaCode = @Variable4)
	BEGIN
	--- checking to see if code already exists
	IF @PK IS NOT NULL
		BEGIN
			
			SET @RawStatement =  CONCAT('SET @PK = (SELECT PKShared_Workgroups FROM Shared_Workgroups WHERE WorkgroupCode = ''',@Variable2,''')',CHAR(13),'exec dbo.spf_SharedWorkgroupCodes_Update 1,''',@location,''',@PK,''',@variable2,''',''',@variable3,''',''',@Variable4,'''')
			PRINT @RawStatement
			---- [CHG7] change this to be correct sproc to update the GRIDS
			exec dbo.spf_SharedWorkgroupCodes_Update 1,@location,@PK,@variable2,@variable3,@Variable4
		END
	ELSE
		BEGIN
			---- [CHG8] change this to be correct sproc for inserting grids
			exec dbo.spf_SharedWorkgroupCodes_Insert 1,@location,@variable2,@variable3,@Variable4
			SET @RawStatement =  CONCAT('exec dbo.spf_SharedWorkgroupCodes_Insert 1,''',@location,''',''',@variable2,''',''',@variable3,''',''',@Variable4,'''')
			PRINT @rawStatement
		END
	END
	ELSE
	BEGIN
	INSERT INTO @errors (errorType,errorMessage,shouldRollback)
		SELECT 'Invalid Shared Area',CONCAT('ERROR Area Code ', @Variable4,' Does not exist.. so Worklist ', @variable2,' Cannot be created or updated'),1
	END	
--=========================================================================
	--------- end of things to do ---------------------------------------------------------------------------------------------------

	-- This should be last and set the id +1 so it does the next row
	SET @i = (@i + 1)
	TRUNCATE TABLE #Grid
END 
----------------------------------------
IF EXISTS (SELECT 1 FROM @errors where shouldRollback = 1)
BEGIN
	--Flattening all rows into a single string
	SELECT @errorMessage =  STUFF(
  (
    SELECT CHAR(13) + errorMessage FROM @errors AS m
	ORDER BY errorMessage DESC
	FOR XML PATH(''), TYPE).value('.', 'nvarchar(max)'),1,1,'')
FROM @errors AS mv
	PRINT @errorMessage
	PRINT CHAR(13)+ CHAR(13) + 'Rolled Back Transaction'
	ROLLBACK
;THROW 60000,@errorMessage,1;

END
ELSE 
BEGIN
	--Flattening all rows into a single string
	SELECT @errorMessage =  STUFF(
  (
    SELECT CHAR(13) + errorMessage FROM @errors AS m
	ORDER BY errorMessage DESC
	FOR XML PATH(''), TYPE).value('.', 'nvarchar(max)'),1,1,'')
	FROM @errors AS mv

	PRINT CHAR(13)+ CHAR(13) + 'Commited Transaction'
	COMMIT
END

END

