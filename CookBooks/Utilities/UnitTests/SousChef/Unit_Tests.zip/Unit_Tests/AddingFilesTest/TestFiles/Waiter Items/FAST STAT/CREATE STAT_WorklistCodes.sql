USE $(TRACDatabase)
GO

/****** Object:  StoredProcedure [spec].[STAT_WorkList_Codes]    Script Date: 4/4/2018 8:08:35 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('[spec].[STAT_WorkList_Codes]') IS NOT NULL
    BEGIN
    DROP PROCEDURE [spec].[STAT_WorkList_Codes]  ;
    PRINT '<<< DROPPED PROCEDURE [spec].[STAT_WorkList_Codes]   >>>';
END;
GO

CREATE PROCEDURE [spec].[STAT_WorkList_Codes] 
/*       COPYRIGHT (c) Huron Healthcare    WRITTEN: Russell Boley   PURPOSE:   Update Or insert Facility Codes   
ASSUMPTIONS:  Files have already been staged <-- not smart enough to know this.    
CHANGE LOG:  2013-01-21: Created      ~CUSTOM~ 		
Initials Date - Adapted for [Client] [HIS] KeyAR Import Master <- Replace with your client and HIS 
SAMPLE CALL:    EXEC [SPEC].[Shared_Facility_Codes] 1, @@SERVERNAME, 1; */
(
	@location VARCHAR(8000) =  NULL,
	@TicketNumber VARCHAR(100) =  NULL
)

AS
BEGIN
  SET NOCOUNT ON;
  SET QUOTED_IDENTIFIER ON;

IF OBJECT_ID('tempdb..#WhileList') IS NOT NULL DROP TABLE #WhileList
IF OBJECT_ID('tempdb..#GRID') IS NOT NULL DROP TABLE #GRID

DECLARE @i int = 1
----- [CHG1] -----
--- Generic Variables pulled from the specs
DECLARE @Variable1 VARCHAR(100)
DECLARE @Variable2 VARCHAR(100)
DECLARE @Variable3 VARCHAR(100)
DECLARE @Variable4 VARCHAR(100)
DECLARE @variable5 VARCHAR(100)
DECLARE @variable6 VARCHAR(100)
DECLARE @variable7 VARCHAR(100)
DECLARE @variable8 VARCHAR(100)
DECLARE @variable9 VARCHAR(100)
DECLARE @variable10 VARCHAR(100)

--- Specific calculated Variables
DECLARE @PK varchar(20)
DECLARE @errors TABLE (MinorCode varchar(50),MajorCode varchar(50),MinorDescription Varchar(50),ErrorMessage VARCHAR(MAX))
DECLARE @Representative varchar(100)
DECLARE @PKAccessCode varchar (50)
DECLARE @workgroupcode varchar(100)

SET @location = 'FAST - CS UPDATES - Shared worklist codes:' + ISNULL(@location,'')

--- CREATING temporary tables 
CREATE TABLE #Grid (PK varchar(20),Variable varchar(50),Operator VARCHAR(50),Value VARCHAR(999))
CREATE TABLE #WhileList (id int IDENTITY(1,1),Variable1 varchar(100),Variable2 VARCHAR(100),Variable3 VARCHAR(100),Variable4 VARCHAR(100),Variable5 VARCHAR(100),Variable6 VARCHAR(100),Variable7 VARCHAR(999),Variable8 VARCHAR(100),variable9 varchar(100),variable10 Varchar(100))

INSERT INTO #WhileList(Variable1,Variable2,Variable3,Variable4,Variable5,Variable6,Variable7,Variable8,variable9,variable10)
SELECT DISTINCT
	-- [CHG2] Add Columns here
	Worklist --variable1
	,[Workgroup Code] --variable2
	,[Worklist Code] --variable3
	,[Worklist Description] --variable4
	,[Rep Code] --variable5
	,IsDisabled --variable 6
	,IsMRGroup --variable 7
	,AccessGroupCode --variable 8
	,[Priority] --variable 9
	,[Transfer Worklist] --variable 10
	-- [CHG2] end of adding columns

FROM spec.SPEC_STAT_Worklist_Specs
WHERE Worklist <> ''
	AND ISNULL(@ticketnumber,CaseNumber) =  CaseNumber --- Adding to create a ticket number filter to only run records for the ticket number.

BEGIN TRAN
----------------WHILE LOOP to enumerate through every user------------------------
WHILE (@i <= (SELECT COUNT(*) FROM #WhileList)) 
BEGIN 


SET @Variable1 = (SELECT Variable1 FROM #WhileList WHERE id = @i)
SET @Variable2 = (SELECT variable2 FROM #WhileList WHERE id = @i)
SET @Variable3 = (SELECT Variable3 FROM #WhileList WHERE id = @i)
SET @Variable4 = (SELECT variable4 FROM #WhileList WHERE id = @i)
SET @variable5 = (SELECT variable5 FROM #WhileList WHERE id = @i)
SET @variable6 = (SELECT variable6 FROM #WhileList WHERE id = @i)
SET @variable7 = (SELECT variable7 FROM #WhileList WHERE id = @i)
SET @variable8 = (SELECT variable8 FROM #WhileList WHERE id = @i)
SET @variable9 = (SELECT variable9 FROM #WhileList WHERE id = @i)
SET @variable10 = (SELECT variable10 FROM #WhileList WHERE id = @i)

------- [CHG3] GET THE assignments PK for updates.-------
---- change this to pull the PK of the assignments needed for determining updates
SET @PK = (
SELECT PKShared_Worklists
	FROM Shared_Workgroups AS a
	INNER JOIN Shared_Worklists AS w
		ON a.PKShared_Workgroups = w.FKShared_WorkGroups
		WHERE WorkgroupCode + WorklistCode = @variable1
		)
---Need to get Workgroup Code in the right format
--- workgroupcode + ' - ' + workgroupdescription
SELECT @workgroupcode =  workgroupcode + ' - ' + workgroupdescription  
FROM Shared_Workgroups
WHERE WorkgroupCode = @Variable2

---Need to get the right format for rep changes
-- Repcode + " - " + RepLastName + ", " + RepFirstName
SELECT @Representative =  RepresentativeCode + ' - ' + RepresentativeLastName + ', ' + RepresentativeFirstName 
FROM Shared_Representatives WHERE RepresentativeCode = @Variable5

--- Need to get the PK for the correct shared access group
SELECT @PKAccessCode = PKShared_AccessGroups 
FROM Shared_AccessGroups WHERE AccessGroupCode = @variable8

----  Do stuff ----
--=========================================================================


PRINT ''
PRINT @variable1 +' | ' + @variable2 +' | '+ @variable3 +' | '+  +' | '+ @variable5 +' | '

--- -- [CHG5] edit this to return whether or not something is valid. like criteria variable or something
IF EXISTS (SELECT 1 FROM Shared_AccessGroups where AccessGroupCode = @variable8)
	BEGIN
	--- checking to see if code already exists
	IF @PK IS NOT NULL
		BEGIN
			PRINT 'UPDATING Worklists' +'|'+@PK+'|'+@workgroupcode+'|'+@Variable3+'|'+@variable4+'|'+@Representative+'|'+@variable6+'|'+@variable7+'|'+@PKAccessCode
			---- [CHG7] change this to be correct sproc to update the GRIDS
			exec dbo.spf_SharedWorklistCodes_Update 1,@location,@PK,@workgroupcode,@Variable3,@variable4,@Representative,@variable6,@variable7,@PKAccessCode
		END
		ELSE
		BEGIN
			PRINT 'INSERTING Worklists' +'|'+ @PK+'|'++'|'+@Variable4+'|'+@variable5
			---- [CHG8] change this to be correct sproc for inserting grids
			exec dbo.spf_SharedWorklistCodes_Insert 1,@location,@workgroupcode,@Variable3,@variable4,@Representative,@variable6,@variable7,@PKAccessCode
		SET @PK = (SELECT PKShared_Worklists FROM Shared_Workgroups AS a INNER JOIN Shared_Worklists AS w ON a.PKShared_Workgroups = w.FKShared_WorkGroups WHERE WorkgroupCode + WorklistCode = @variable1)
		END
	--SELECT @PK,@Variable3,@Variable2,@Variable4,@variable5,@variable9,@variable10
	--Only want to update assignments if non-sticky or has priority
	IF @variable9 <> 'NULL'
		BEGIN
			PRINT 'Updating STAT Worklist ' +'|'+ @PK+'|Worklist:'+ @variable10 +'|Priority:'+@Variable9+'|Transfer:'+@variable10
			exec dbo.spf_STATWorklistCodes_Update 1,@location,@PK,@Variable3,@Variable2,@Variable4,@variable5,@variable9,@variable10
		END
	END

	ELSE
	BEGIN
	INSERT INTO @errors (MinorCode,MinorDescription,MajorCode,ErrorMessage)
		SELECT @Variable1,@Variable2,@variable3,'ERROR Access Group ' + @variable8 + ' Does not exist.. so Worklist ' + @variable2 + ' Cannot be created or updated'
	END	


--=========================================================================
	--------- end of things to do ---------------------------------------------------------------------------------------------------

	-- This should be last and set the id +1 so it does the next row
	SET @i = (@i + 1)
	TRUNCATE TABLE #Grid
END 
----------------------------------------
--COMMIT 
SELECT * FROM @errors
COMMIT

END;

GO


