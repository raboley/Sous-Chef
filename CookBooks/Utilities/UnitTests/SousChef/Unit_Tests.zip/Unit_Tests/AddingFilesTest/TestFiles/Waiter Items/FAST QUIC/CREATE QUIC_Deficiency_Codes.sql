USE $(TRACDatabase)
/****** Object:  StoredProcedure [SPEC].[QUIC_Deficiency_Codes]    Script Date: 3/20/2018 3:10:59 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('[SPEC].[QUIC_Deficiency_Codes]') IS NOT NULL
    BEGIN
    DROP PROCEDURE [SPEC].[QUIC_Deficiency_Codes] ;
    PRINT '<<< DROPPED PROCEDURE [SPEC].[QUIC_Deficiency_Codes]  >>>';
END;
GO

CREATE PROCEDURE [SPEC].[QUIC_Deficiency_Codes] 
/*       COPYRIGHT (c) Huron Healthcare    WRITTEN: Russell Boley   PURPOSE:   Update Or insert Facility Codes   
ASSUMPTIONS:  Files have already been staged <-- not smart enough to know this.    
CHANGE LOG:  2013-01-21: Created      ~CUSTOM~ 		
Initials Date - Adapted for [Client] [HIS] KeyAR Import Master <- Replace with your client and HIS 
SAMPLE CALL:    EXEC [SPEC].[Shared_Facility_Codes] 1, @@SERVERNAME, 1; */
(
	@location VARCHAR(8000) =  NULL,
	@TicketNumber VARCHAR(100) =  NULL,
	@debug BIT =0
)

AS
BEGIN
  SET NOCOUNT ON;
  SET QUOTED_IDENTIFIER ON;

IF OBJECT_ID('tempdb..#WhileList') IS NOT NULL DROP TABLE #WhileList
IF OBJECT_ID('tempdb..#GRID') IS NOT NULL DROP TABLE #GRID

DECLARE @i int = 1
----- [CHG1] -----
--- Generic Variables pulled from the specs
DECLARE @Variable1 VARCHAR(100)
DECLARE @Variable2 VARCHAR(100)
DECLARE @Variable3 VARCHAR(100)
DECLARE @Variable4 VARCHAR(100)
DECLARE @variable5 VARCHAR(100)
DECLARE @variable6 VARCHAR(100)
DECLARE @variable7 VARCHAR(100)
DECLARE @variable8 VARCHAR(100)
DECLARE @variable9 VARCHAR(100)
DECLARE @variable10 VARCHAR(100)

--- Specific calculated Variables
DECLARE @PK varchar(20)
DECLARE @errors TABLE (MinorCode varchar(50),MajorCode varchar(50),MinorDescription Varchar(50),ErrorMessage VARCHAR(MAX))
DECLARE @Representative varchar(100)
DECLARE @PKAccessCode varchar (50)
DECLARE @workgroupcode varchar(100)



--Deficiency Codes
--exec dbo.spf_QUICDeficiencyCodes_Insert @LastModifiedBy,@Location,@DeficiencyCode,@defDesc,@AreaCode,@DeficiencyPriority,@SourceCode,@IsInfoOnly,@defDelDays,@DeficiencyComments,@IsDisabled

--- CREATING temporary tables 
CREATE TABLE #Grid (PK varchar(20),Variable varchar(50),Operator VARCHAR(50),Value VARCHAR(999))
CREATE TABLE #WhileList (id int IDENTITY(1,1),Variable1 varchar(100),Variable2 VARCHAR(100),Variable3 VARCHAR(100),Variable4 VARCHAR(100),Variable5 VARCHAR(100),Variable6 VARCHAR(100),Variable7 VARCHAR(999),Variable8 VARCHAR(100),variable9 varchar(100),variable10 Varchar(100))

INSERT INTO #WhileList(Variable1,Variable2,Variable3,Variable4,Variable5,Variable6,Variable7,Variable8,variable9)
SELECT DISTINCT
	-- [CHG2] Add Columns here
	DeficiencyCode --variable1
	,DeficiencyDescription --variable2
	,AreaCode --variable3
	,DeficiencyPriority --variable4
	,SourceCode --variable5
	,IsInfoOnly --variable 6
	,DelinquentDays --variable 7
	,DeficiencyComments --variable 8
	,IsDisabled --variable 9
	--'1'
	-- [CHG2] end of adding columns

FROM spec.SPEC_QUIC_Billholds
WHERE AreaCode <> ''
and(
	( @ticketnumber is not null and ticket =@TicketNumber)
	OR 
	( @ticketnumber is null)
	)

order by deficiencypriority
	

BEGIN TRAN
----------------WHILE LOOP to enumerate through every user------------------------
WHILE (@i <= (SELECT COUNT(*) FROM #WhileList)) 
BEGIN 


SET @Variable1 = (SELECT Variable1 FROM #WhileList WHERE id = @i)
SET @Variable2 = (SELECT variable2 FROM #WhileList WHERE id = @i)
SET @Variable3 = (SELECT Variable3 FROM #WhileList WHERE id = @i)
SET @Variable4 = (SELECT variable4 FROM #WhileList WHERE id = @i)
SET @variable5 = (SELECT variable5 FROM #WhileList WHERE id = @i)
SET @variable6 = (SELECT variable6 FROM #WhileList WHERE id = @i)
SET @variable7 = (SELECT variable7 FROM #WhileList WHERE id = @i)
SET @variable8 = (SELECT variable8 FROM #WhileList WHERE id = @i)
SET @variable9 = (SELECT variable9 FROM #WhileList WHERE id = @i)
SET @variable10 = (SELECT variable10 FROM #WhileList WHERE id = @i)

------- [CHG3] GET THE assignments PK for updates.-------
---- change this to pull the PK of the assignments needed for determining updates
SET @PK = (
SELECT PKQUIC_DeficiencyCodes
	FROM QUIC_DeficiencyCodes AS a
	WHERE DeficiencyCode=@Variable1
		
)

--SELECT @PKAccessCode = PKShared_AccessGroups 
--FROM Shared_AccessGroups WHERE AccessGroupCode = @variable10

----  Do stuff ----
--=========================================================================


--PRINT ''
--PRINT @variable1 +' | ' + @variable2 +' | '+ @variable3 +' | '+  +' | '+ @variable5 +' | '

--- -- [CHG5] edit this to return whether or not something is valid. like criteria variable or something
IF EXISTS (SELECT 1 FROM Shared_Areas where AreaCode=@Variable3)
	BEGIN
	--- checking to see if code already exists
	IF @PK IS NOT NULL
		BEGIN
			IF (@debug=1)
			BEGIN
			 PRINT 'exec dbo.spf_QUICDeficiencyCodes_Update 1,'''+@location+''','+cast(@PK as varchar)+','''+@Variable1+''','''+@variable2+''','''+@Variable3+''','''+@Variable4+''','''+@Variable5+''','''+@Variable6+''','''+@Variable7+''','''+@Variable8+''','''+@Variable9+''''
			END
			IF (@debug=0)
			BEGIN
			 exec dbo.spf_QUICDeficiencyCodes_Update 1,@location,@PK,@Variable1,@Variable2,@Variable3,@variable4,@variable5,@variable6,@variable7,@variable8,@variable9--,@variable10
			END
			--PRINT 'UPDATING Worklists' +'|'+@PK+'|'+@Variable3+'|'+@variable4+'|'+@Representative+'|'+@variable6+'|'+@variable7+'|'+@PKAccessCode
		
	
		END
		ELSE
		BEGIN
			IF (@debug=1)
			BEGIN
			 PRINT 'exec dbo.spf_QUICDeficiencyCodes_Insert 1,'''+@location+''','''+@Variable1+''','''+@variable2+''','''+@Variable3+''','''+@Variable4+''','''+@Variable5+''','''+@Variable6+''','''+@Variable7+''','''+@Variable8+''','''+@Variable9+''''
			END
			IF (@debug=0)
			BEGIN
			 exec dbo.spf_QUICDeficiencyCodes_Insert 1,@location,@Variable1,@Variable2,@Variable3,@variable4,@variable5,@variable6,@variable7,@variable8,@variable9
			END
			--PRINT 'INSERTING Worklists' +'|'+ @PK+'|'++'|'+@Variable4+'|'+@variable5
			---- [CHG8] change this to be correct sproc for inserting grids
			--,@variable10
		END
	--SELECT @PK,@Variable3,@Variable2,@Variable4,@variable5,@variable9,@variable10
	--Only want to update assignments if non-sticky or has priority
	
	END

	ELSE
	BEGIN
	INSERT INTO @errors (MinorCode,MinorDescription,MajorCode,ErrorMessage)
		SELECT @Variable1,@Variable2,@variable3,'ERROR Area ' + @variable8 + ' Does not exist.. so Deficiency ' + @variable2 + ' Cannot be created or updated'
	END	


--=========================================================================
	--------- end of things to do ---------------------------------------------------------------------------------------------------

	-- This should be last and set the id +1 so it does the next row
	SET @i = (@i + 1)
	TRUNCATE TABLE #Grid
END 
----------------------------------------
--COMMIT 
SELECT * FROM @errors
SELECT TOP 100 PERCENT
QDC.DeficiencyCode,
ISNULL(QDC.DeficiencyDescription,'') AS DeficiencyDescription,
AREA.AreaCode,
QDC.DeficiencyPriority,
QSRC.SourceCode,
QDC.DelinquentDays,
QDC.IsInfoOnly,
QDC.IsDisabled,
ISNULL(QDC.DeficiencyComments,'') AS DeficiencyComments,
BHA.BillholdVariable,
BHA.BillholdOperator,
BHA.BillholdValue,
BH.BillholdExecutionOrder,
BHD.BillholdDeficiencyOrder
FROM
QUIC_DeficiencyCodes QDC
LEFT JOIN Shared_Areas AREA
ON QDC.FKShared_Areas = AREA.PKShared_Areas
LEFT JOIN QUIC_Sources QSRC
ON QDC.FKQUIC_Sources = QSRC.PKQUIC_Sources
INNER JOIN QUIC_BillholdDeficiencies BHD
INNER JOIN QUIC_Billholds BH
INNER JOIN QUIC_BillholdAssignments BHA
ON BH.PKQUIC_Billholds = BHA.FKQUIC_Billholds
ON BHD.FKQUIC_Billholds = BH.PKQUIC_Billholds
ON BHD.FKQUIC_DeficiencyCodes = QDC.PKQUIC_DeficiencyCodes
where bha.location=@location or bhd.Location=@location or bh.Location=@location
ORDER BY QDC.DeficiencyCode, BillholdExecutionOrder
COMMIT

END;


