/* ----------------------------------------------------------------------------------------------------
This script should take worklists that need to be alpha split, and determine the correct alpha splits for them.

The idea is to put a criteria variable of 'AutoAlphaSplit' and then it will split it based on all the accounts assigned to the workgroup.

-- Should think about adding something that excludes other worklists on the workgroup, or takes into account other criteria
-- add logic to do more than one group at a time
*/

DECLARE @Worklists TABLE(id int IDENTITY(1,1),Worklist VARCHAR(4),WorklistDescription VARCHAR(100))
DECLARE @Splits INT
DECLARE @Boundary INT
DECLARE @Granularity INT
DECLARE @Tweak INT

SELECT DISTINCT Worklist
FROM spec.SPEC_STAT_Worklist_Specs
WHERE value = 'AutoAlphaSplit'

--- Inserting into the temporary table all worklists that need to be split
INSERT INTO @Worklists
	SELECT DISTINCT Worklist,[Worklist Description]
	FROM spec.SPEC_STAT_Worklist_Specs
	WHERE value = 'AutoAlphaSplit'

-- The number of worklists the alpha split will increase or decrease to.
SET @Splits = (SELECT COUNT(*) FROM @Worklists) 
SET @Granularity = 4 -- How many characters in the patient's last name are evaluated when calculating alpha splits.
SET @Tweak = 1 -- ???

-- Getting some calculation of the average or something, so that the alpha splits teter around that number
SELECT @Boundary = ROUND((COUNT(*) / @Splits), 0) + @Tweak
FROM (
	SELECT LEFT(PatientName, @Granularity) AS LastName
	FROM TE
	
	--- this is a potential thing that has too change. made it look at workgroup, instead of group of worklists
	JOIN @Worklists AS TBL ON (te.WorkGroup) = LEFT(TBL.Worklist,2)
	where accountbalance <> 0
	) AS SUB

SELECT @Boundary

-- Create a temp table to store the splits
IF OBJECT_ID('tempdb..#NameTable') IS NOT NULL
	DROP TABLE #NameTable

IF OBJECT_ID('tempdb..#tempSpecs') IS NOT NULL
	DROP TABLE #tempSpecs

CREATE TABLE #NameTable (
	id int IDENTITY(1,1)
	,Start VARCHAR(25)
	,[End] VARCHAR(25)
	,WLSize INT
	);

DECLARE NAMES CURSOR FAST_FORWARD
FOR
WITH CTENAMES
AS (
	SELECT RN = ROW_NUMBER() OVER (
			ORDER BY LEFT(PatientName, @Granularity)
			)
		,LEFT(PatientName, @Granularity) AS LastName
		,COUNT(*) AS NUM
		from te
	--- this is a potential thing that has too change. made it look at workgroup, instead of group of worklists
	JOIN @Worklists AS TBL ON (te.WorkGroup) = LEFT(TBL.Worklist,2)
	GROUP BY LEFT(PatientName, @Granularity)
	)
SELECT CUR.LastName AS LastName
	,SND.LastName AS NextName
	,CUR.NUM AS NUM
FROM CTENAMES AS CUR
JOIN CTENAMES AS SND ON SND.RN = CUR.RN + 1
ORDER BY LastName

DECLARE @LName VARCHAR(25)
DECLARE @NName VARCHAR(25)
DECLARE @Num INT
DECLARE @Total INT
DECLARE @PrevName VARCHAR(25)
DECLARE @TempNAme VARCHAR(25)
DECLARE @LEnd VARCHAR(25)
DECLARE @Frst BIT

SET @Total = 0
SET @Frst = 0

OPEN NAMES

FETCH NEXT
FROM NAMES
INTO @LName
	,@NName
	,@Num

WHILE @@FETCH_STATUS = 0
BEGIN
	SET @Num = @Total + @Num

	-- If the number of accounts has reached the boundary for the current group
	IF @Num >= @Boundary
	BEGIN
		-- Select which name gets us closer to the boundary
		IF (@Num - @Boundary) > (@Boundary - @Total)
		BEGIN
			SET @TempName = @PrevName
			SET @NName = @LName
			SET @Total = @Num - @Total
		END
		ELSE
		BEGIN
			SET @TempName = @LName
			SET @Total = 0
		END

		--PRINT 'DIFF of ' + @TempName + '- ' + @NName + ' : ' + @LEnd + ' ' + CONVERT(VARCHAR(10), @Frst)
		DECLARE @LOC INT

		SET @LOC = 1

		WHILE @LOC <= @Granularity
		BEGIN
			IF LEFT(@TempName, @LOC) <> LEFT(@NName, @LOC)
			BEGIN
				SET @NName = LEFT(@TempName, @LOC) + 'Z'

				BREAK
			END

			SET @LOC = @LOC + 1
		END

		IF @Frst = 0
			SET @LEnd = 'AAA'
		ELSE
			SET @LEnd = LEFT(@LEnd, LEN(@LEnd) - 2) + CHAR(ASCII(LEFT(RIGHT(@LEnd, 2), 1)) + 1)

		INSERT INTO #NameTable (
			Start
			,[End]
			,WLSize
			)
		SELECT @LEnd
			,@NName
			,@Num

		SET @LEnd = @NName
		SET @Frst = 1
	END
	ELSE
		SET @Total = @Num

	SET @PrevName = @LName

	FETCH NEXT
	FROM NAMES
	INTO @LName
		,@NName
		,@Num

	IF @@FETCH_STATUS <> 0
		INSERT INTO #NameTable (
			Start
			,[END]
			,WLSize
			)
		SELECT (LEFT(@LEnd, LEN(@LEnd) - 2) + CHAR(ASCII(LEFT(RIGHT(@LEnd, 2), 1)) + 1))
			,'ZZZ'
			,@Num
END

CLOSE NAMES

DEALLOCATE NAMES

--SELECT *
--FROM #NameTable



SELECT w.Worklist,WorklistDescription,WorklistDescription +' '+ Start + '-' + [End] as 'NewDescription','START' as 'location'
,'PatientLastName' as 'criteria','>=' as 'Operator',n.Start as 'value'

INTO #tempSpecs

FROM @Worklists w
	JOIN #NameTable n
		on n.id = w.id

	UNION
SELECT w.Worklist,WorklistDescription,WorklistDescription +' '+ Start + '-' + [End],'END'
,'PatientLastName' as 'criteria','<=' as 'Operator',n.[End]
FROM @Worklists w
	JOIN #NameTable n
		on n.id = w.id
ORDER BY worklist,location desc
	


--SELECT * 
--FROM #tempSpecs s
--	JOIN spec.SPEC_STAT_Worklist_Specs specs
--	ON specs.Worklist = s.Worklist
--	AND s.Operator = specs.[Assignment Criteria Operator]
--	WHERE specs.value = 'AutoAlphaSplit'

UPDATE spec.SPEC_STAT_Worklist_Specs
set Value = s.value,
	[Worklist Description] = s.NewDescription
FROM #tempSpecs s
	JOIN spec.SPEC_STAT_Worklist_Specs specs
	ON specs.Worklist = s.Worklist
	AND s.Operator = specs.[Assignment Criteria Operator]
	WHERE specs.value = 'AutoAlphaSplit'

--SELECT wl.*
--FROM @Worklists w
--	JOIN spec.SPEC_STAT_Worklist_Specs wl
--		ON wl.Worklist = w.Worklist

DROP TABLE #tempSpecs
DROP TABLE #NameTable
