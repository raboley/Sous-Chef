USE $(TRACDatabase)
GO

/****** Object:  StoredProcedure [spec].[STAT_WorkList_Assignments]    Script Date: 4/4/2018 8:08:32 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('[spec].[STAT_WorkList_Assignments]') IS NOT NULL
    BEGIN
    DROP PROCEDURE [spec].[STAT_WorkList_Assignments]  ;
    PRINT '<<< DROPPED PROCEDURE [spec].[STAT_WorkList_Assignments]   >>>';
END;
GO


CREATE PROCEDURE [spec].[STAT_WorkList_Assignments] 

/*       COPYRIGHT (c) Huron Healthcare    WRITTEN: Russell Boley   PURPOSE:   Update Or insert Facility Codes   
ASSUMPTIONS:  Files have already been staged <-- not smart enough to know this.    
CHANGE LOG:  2013-01-21: Created      ~CUSTOM~ 		
Initials Date - Adapted for [Client] [HIS] KeyAR Import Master <- Replace with your client and HIS 
SAMPLE CALL:    EXEC [SPEC].[Shared_Facility_Codes] 1, @@SERVERNAME, 1; */

(
	@location VARCHAR(8000)= NULL,
	@CaseNumber VARCHAR(100)= NULL
)
AS
BEGIN
  SET NOCOUNT ON;
  SET QUOTED_IDENTIFIER ON;

IF OBJECT_ID('tempdb..#WhileList') IS NOT NULL DROP TABLE #WhileList
IF OBJECT_ID('tempdb..#GRID') IS NOT NULL DROP TABLE #GRID

DECLARE @i int = 1
----- [CHG1] -----
DECLARE @Variable1 VARCHAR(100)
DECLARE @Variable2 VARCHAR(100)
DECLARE @Variable3 VARCHAR(100)
DECLARE @Variable4 VARCHAR(100)
DECLARE @variable5 VARCHAR(MAX)
DECLARE @variable6 VARCHAR(100)
DECLARE @variable7 VARCHAR(MAX)
DECLARE @variable8 VARCHAR(100)
DECLARE @PK varchar(20)
DECLARE @PKAssignments int
DECLARE @PKShared int
DECLARE @errors TABLE (MinorCode varchar(50),MajorCode varchar(50),MinorDescription Varchar(50),ErrorMessage VARCHAR(MAX))
DECLARE @PKGrid varchar(20)
DECLARE @operator varchar (50)
DECLARE @workgroup Varchar(2)

SET @location = 'FAST - Worklist Assignments:' + ISNULL(@location,'')

CREATE TABLE #Grid (PK varchar(20),Variable varchar(50),Operator VARCHAR(50),Value VARCHAR(999),AssignmentGroup VARCHAR(20))
CREATE TABLE #WhileList (id int IDENTITY(1,1) ,Variable1 varchar(100),Variable2 VARCHAR(100),Variable3 VARCHAR(100),Variable4 VARCHAR(100),Variable5 VARCHAR(999),variable6 VARCHAR(100),variable7 varchar(MAX),variable8 VARCHAR(100))

DECLARE @count int = 0


INSERT INTO #WhileList(Variable1,Variable2,Variable3,Variable4,Variable5,variable6,variable7,variable8)
SELECT DISTINCT
	-- [CHG2] Add Columns here
	 [Priority] --variable1
	,Worklist--variable2
	,[Workgroup Code]--variable3
	,[Initial Followup] --variable4
	,[Assignment Criteria Variable] --variable5
	,[Assignment Criteria Operator] --variable 6
	,[Value] --variable 7
	,[Group] --variable 8
	-- [CHG2] end of adding columns
FROM spec.SPEC_STAT_Worklist_Specs
WHERE [Assignment Criteria Variable] NOT IN ('NULL','')
	AND ISNULL(@caseNumber,CaseNumber) =  CaseNumber --- Adding to create a ticket number filter to only run records for the ticket number.

BEGIN TRAN
----------------WHILE LOOP to enumerate through every user------------------------
WHILE (@i <= (SELECT COUNT(*) FROM #WhileList)) 
BEGIN 


SET @Variable1 = (SELECT Variable1 FROM #WhileList WHERE id = @i)
SET @Variable2 = (SELECT variable2 FROM #WhileList WHERE id = @i)
SET @Variable3 = (SELECT Variable3 FROM #WhileList WHERE id = @i)
SET @Variable4 = (SELECT variable4 FROM #WhileList WHERE id = @i)
SET @variable5 = (SELECT variable5 FROM #WhileList WHERE id = @i)
SET @variable6 = (SELECT variable6 FROM #WhileList WHERE id = @i)
SET @variable7 = (SELECT variable7 FROM #WhileList WHERE id = @i)
SET @variable8 = (SELECT variable8 FROM #WhileList WHERE id = @i)


--- GETTING THE accepted Operator (if operators are used make sure Variable 4 is the operator)
SET @operator = (SELECT AssignmentOperator + ' ' + AssignmentOperatorDescription FROM Shared_AssignmentOperators WHERE AssignmentOperator = @variable6)

------- [CHG3] GET THE assignments PK for updates.-------
---- change this to pull the PK of the assignments needed for determining updates
SET @PK = (SELECT
	a.PKSTAT_WorklistAssignments
FROM STAT_WorklistAssignments AS a
INNER JOIN Shared_Worklists AS w
	ON a.FKShared_Worklists = w.PKShared_Worklists
INNER JOIN Shared_Workgroups SWG
	ON SWG.PKShared_Workgroups = W.FKShared_WorkGroups
	WHERE SWG.WorkgroupCode +  WorklistCode = @Variable2)

--- Getting just the workgroup code for the assignments update

-- [CHG4] GET THE PK For the grid if needing to update
INSERT INTO #Grid (PK,Variable,Operator,Value,AssignmentGroup)
exec dbo.spf_STATWorklistAssignments_SAGrid18_FillGrid @PK

--- Getting the PK of the assignments grid.  top is based on just variable name and group if possible, if there are more than 1 of a variable then do it on variable and operator and group.
SET @count = (SELECT COUNT(*) FROM #Grid WHERE Variable = @Variable5 and AssignmentGroup = @variable8)
SET @count = @count + (SELECT COUNT(*) FROM #WhileList WHERE variable5 = @Variable5 and variable8 = @variable8)
IF (@count <= 2)
BEGIN
	SET @PKGRID = (SELECT PK FROM #Grid WHERE Variable = @Variable5 and AssignmentGroup = @variable8)
END
ELSE 
BEGIN
	SET @PKGRID = (SELECT PK FROM #Grid WHERE Variable = @Variable5 and AssignmentGroup = @variable8 AND Operator = @operator)
END
----  Do stuff ----
--=========================================================================

PRINT ''
PRINT @variable1 +' | ' + @variable2 +' | '+ @variable3 +' | '+ @operator +' | '+ @variable5 +' | '


--- -- [CHG5] edit this to return whether or not something is valid. like criteria variable or something
IF EXISTS (SELECT 1 FROM STAT_AssignmentCriteriaNames WHERE AssignmentCriteriaVariable =  @Variable5)
	BEGIN
	IF @PK IS NULL
		BEGIN
		PRINT 'INSERTING into Worklist Assingments'
		---- [CHG6] change this to be the correct insert sproc if something needs to be inserted to assignmetns
		exec dbo.spf_STATWorklistAssignments_Insert 1,@location,@Variable2,@Variable4,@Variable1
		--exec dbo.spf_STATWorklistCodes_FacilityGrid_InsertGrid 1,@location,69,'1'
		----------- change this to pull the PK of the assignments needed for determining updates
		SET @PK = (SELECT a.PKSTAT_WorklistAssignments
			FROM STAT_WorklistAssignments AS a
			INNER JOIN Shared_Worklists AS w
				ON a.FKShared_Worklists = w.PKShared_Worklists
			INNER JOIN Shared_Workgroups SWG
				ON SWG.PKShared_Workgroups = W.FKShared_WorkGroups
			WHERE SWG.WorkgroupCode +  WorklistCode = @Variable2)
		-----------
		END
		ELSE
		BEGIN
			PRINT 'Updating WorkList Assingments'
			exec dbo.spf_STATWorklistAssignments_Update 1,@location,@PK,@Variable2,@Variable4,@Variable1
		END

	IF @PKGrid IS NULL
	--- checking to see if code already exists
		BEGIN
			PRINT 'INSERTING WorkList GRIDS' +'|PKGrid:'+@PKGrid+'|variable5:'+@variable5+'|operator:'+@operator+'|variable7:'+@variable7+'|variable8:'+@variable8
			---- [CHG8] change this to be correct sproc for inserting grids
			exec dbo.spf_STATWorklistAssignments_SAGrid18_InsertGrid 1,@location,@PK,@variable5,@operator,@variable7,@variable8
			

		END
		ELSE
		BEGIN
			PRINT 'UPDATING WorkList GRIDS' +'|PKGrid:'+@PKGrid+'|variable5:'+@variable5+'|operator:'+@operator+'|variable7:'+@variable7+'|variable8:'+@variable8
			---- [CHG8] change this to be correct sproc for inserting grids
			exec dbo.spf_STATWorklistAssignments_SAGrid18_UpdateGrid 1,@location,@PKGrid,@variable5,@operator,@variable7,@variable8
		END
	END
	ELSE
	BEGIN
	INSERT INTO @errors (MinorCode,MinorDescription,MajorCode,ErrorMessage)
		SELECT @Variable1,@Variable2,@variable3,'ERROR variable ' + @Variable5 + ' Does not exist.. so worklist code ' + @variable2 + ' Assignments Cannot be created or updated'
	END
--=========================================================================
	--------- end of things to do ---------------------------------------------------------------------------------------------------

	-- This should be last and set the id +1 so it does the next row
	SET @i = (@i + 1)
	TRUNCATE TABLE #Grid
END 
----------------------------------------
--COMMIT 
SELECT * FROM @errors
COMMIT

END;



GO


