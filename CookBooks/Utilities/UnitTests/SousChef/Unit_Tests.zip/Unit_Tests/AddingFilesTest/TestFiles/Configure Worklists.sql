
--- Worklists
-- DECLARE @PKExceptionWorklist int = 829,
-- 		@PKExceptionWorkGroup int = 145

-- DELETE FROM STAT_WorkgroupAssignmentCriteria
-- --DELETE FROM STAT_WorkgroupAssignments

-- --DELETE FROM STAT_Worklist_Facilities
-- DELETE FROM STAT_WorklistAssignmentCriteria
-- --DELETE FROM STAT_WorklistAssignments
-- --DELETE FROM STAT_Worklists WHERE FKShared_Worklists <> @PKExceptionWorklist
-- --DELETE FROM Shared_Worklists where PKShared_Worklists <> @PKExceptionWorklist

-- --DELETE FROM Shared_Workgroups WHERE PKShared_Workgroups <> @PKExceptionWorkGroup
-- --UPDATE Shared_ExceptionTypes set FKShared_Worklists  =NULL
-- --- STAT Worklist & Workgroups
exec spec.STAT_WorkGroup_Codes '$(Location)','$(CaseNumber)'
exec spec.STAT_WorkGroup_Assignments '$(Location)','$(CaseNumber)'

exec spec.STAT_Worklist_Codes '$(Location)','$(CaseNumber)'
exec spec.STAT_WorkList_Assignments '$(Location)','$(CaseNumber)'

