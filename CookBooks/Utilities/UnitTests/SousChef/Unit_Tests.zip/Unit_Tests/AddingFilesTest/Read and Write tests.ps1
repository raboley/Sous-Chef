﻿Add-Type -AssemblyName Microsoft.VisualBasic
$errorAction = "Stop"
Get-Variable -Exclude PWD,*Preference | Remove-Variable -EA 0
function Remove-Item-ToRecycleBin($Path) {
    $item = Get-Item -Path $Path -ErrorAction SilentlyContinue
    if ($item -eq $null)
    {
        Write-Error("'{0}' not found" -f $Path)
    }
    else
    {
        $fullpath=$item.FullName
        Write-Verbose ("Moving '{0}' to the Recycle Bin" -f $fullpath)
        if (Test-Path -Path $fullpath -PathType Container)
        {
            [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteDirectory($fullpath,'OnlyErrorDialogs','SendToRecycleBin')
        }
        else
        {
            [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile($fullpath,'OnlyErrorDialogs','SendToRecycleBin')
        }
    }
}


$syncHash = @{
    RootDirectory = "C:\Russell\Tools\Git\RCWorkflow_Implementation\PIT_Tools\HT_SousChef"; #Split-Path -parent $MyInvocation.MyCommand.Definition
    #RecipeFolderPath = Join-Path $syncHash.RootDirectory "\CookBooks\Unit_Tests\AddingFilesTest\";
    #Get_Recipe = Join-path $syncHash.RootDirectory "\Config\Scripts\Get_Recipe.ps1";
    #Save_Recipe = Join-path $syncHash.RootDirectory "\Config\Scripts\Save_Recipe.ps1";
}


$syncHash.RootDirectory = "C:\Users\rboley\Desktop\git\RCWorkflow_Implementation\PIT_Tools\HT_SousChef"
$syncHash.RootDirectory =  "C:\Russell\Tools\Git\RCWorkflow_Implementation\PIT_Tools\HT_SousChef"
$synchash.CurrentRecipeFolderPartPath = "\CookBooks\Unit_Tests\AddingFilesTest\"
$synchash.CurrentRecipeFolderPath = Join-Path $syncHash.RootDirectory "\CookBooks\Unit_Tests\AddingFilesTest\"
$syncHash.CurrentRecipePartPath = "\CookBooks\Unit_Tests\AddingFilesTest\AddFiles.recipe"
$syncHash.RecipeExtensions = ".xml",".recipe",".order"

function Update-CurrentRecipe ($synchash,$RecipePath) {
    $synchash.CurrentRecipePath = $RecipePath
    $synchash.CurrentRecipeName = Split-Path $RecipePath -Leaf
    $syncHash.CurrentRecipePartPath = $RecipePath.replace($synchash.rootdirectory,"")
    $synchash.CurrentRecipeFolderPath = Split-Path $RecipePath -Parent
    $synchash.CurrentRecipeFolderPartPath = $synchash.CurrentRecipeFolderPath.replace($syncHash.rootdirectory,"")
    
    return $synchash
}

### commands
$syncHash.Get_Recipe_Items = Join-path $syncHash.RootDirectory "\Config\Scripts\Get_Recipe_Items.ps1"
$syncHash.Get_Recipe_Variables = Join-path $syncHash.RootDirectory "\Config\Scripts\Get_Recipe_Variables.ps1"
$syncHash.Add_Recipe_Items = Join-path $syncHash.RootDirectory "\Config\Scripts\Add_Recipe_Items.ps1"
$syncHash.Save_Recipe = Join-path $syncHash.RootDirectory "\Config\Scripts\Save_Recipe.ps1"
$syncHash.Add_Script = Join-path $syncHash.RootDirectory "\Config\Scripts\Add_Script.ps1"
$syncHash.Add_File = Join-path $syncHash.RootDirectory "\Config\Scripts\Add_File.ps1"
$syncHash.File_Waiter = Join-path $syncHash.RootDirectory "\Config\Scripts\File_Waiter.ps1"
$syncHash.Cook_Order = Join-path $syncHash.RootDirectory "\Config\Scripts\Cook_Order.ps1"
$syncHash.Open_File = Join-path $syncHash.RootDirectory "\Config\Scripts\Open_File.ps1"


### the variables
$testSpacePath = "\CookBooks\Unit_Tests\AddingFilesTest\TestSpace"
$deleteTestPathFolder = Join-Path $syncHash.RootDirectory $testSpacePath
if(test-path $deleteTestPathFolder){
    #remove-item (Join-Path $syncHash.RootDirectory $testSpacePath) -WhatIf
    Write-Host "Move to Recycle bin:$deleteTestPathFolder"
    Remove-Item-ToRecycleBin $deleteTestPathFolder
}

$baseRecipeName = "BaseRecipe.recipe"
$BaseRecipePartPath = Join-Path $testSpacePath "BaseRecipe\$baseRecipeName"
$BaseRecipePath = Join-Path $synchash.rootdirectory $BaseRecipePartPath

$ParentRecipeName = "ParentRecipe.recipe"
$ParentRecipePartPath = Join-Path $testSpacePath "ParentRecipe\$ParentRecipeName"
$ParentRecipePath = Join-Path $synchash.rootdirectory $ParentRecipePartPath

$OrderRecipeName = "OrderRecipe.order"
$OrderRecipePartPath = Join-Path $testSpacePath "OrderRecipe\$OrderRecipeName"
$OrderRecipePath = Join-Path $synchash.rootdirectory $OrderRecipePartPath

$waiterRecipeName = "waiterRecipe.recipe"
$waiterRecipePartPath = Join-Path $testSpacePath "Waiter Items\waiterRecipe\$waiterRecipeName"
$waiterRecipePath = Join-Path $synchash.rootdirectory $waiterRecipePartPath
$waiterRecipeFolder = Split-Path $waiterrecipePath -Parent

$waiterorderName = "waiterorder.order"
$waiterorderPartPath = Join-Path $testSpacePath "Waiter Items\waiterRecipe\$waiterorderName"
$waiterorderPath = Join-Path $synchash.rootdirectory $waiterorderPartPath
$waiterorderFolder = Split-Path $waiterorderPath -Parent

$waiterFolderRecipeName = "waiterFolderRecipe.recipe"
$waiterFolderRecipePartPath = Join-Path $testSpacePath "waiter Items\waiterFolderRecipe\$waiterFolderRecipeName"
$waiterFolderRecipePath = Join-Path $synchash.rootdirectory $waiterFolderRecipePartPath

#### test files
$testFilesPath = join-path $synchash.rootdirectory "\CookBooks\Unit_Tests\AddingFilesTest\TestFiles"

$BaseRecipeScriptName = "Simple Convert Specs to CSV.ps1"
$baseRecipeScript = Join-Path $testFilesPath $BaseRecipeScriptName
$baseRecipeScriptDestination = Join-Path (Split-Path $BaseRecipePath -parent) $baserecipeScriptName

$BaseRecipeScript2Name = "Spec_CSV_to_SQL.ps1"
$BaseRecipeScript2 = Join-Path $testFilesPath $BaseRecipeScript2Name
$BaseRecipeScript2Destination = Join-Path (Split-Path $BaseRecipePath -parent) $BaseRecipeScript2Name

$ParentRecipeScriptName = "Determine Auto Alpha Splits.sql"
$ParentRecipeScript = Join-Path $testFilesPath $ParentRecipeScriptName
$ParentRecipeScriptDestination = Join-Path (Split-Path $ParentRecipePath -parent) $ParentrecipeScriptName

$ParentRecipeScript2Name = "Configure Worklists.sql"
$ParentRecipeScript2 = Join-Path $testFilesPath $ParentRecipeScript2Name
$ParentRecipeScript2Destination = Join-Path (Split-Path $ParentRecipePath -parent) $ParentRecipeScript2Name

#### Waiter files
$testFilesPath = Join-Path $synchash.RootDirectory "\CookBooks\Unit_Tests\AddingFilesTest\TestFiles"
$WaiterOneFileTest = Join-Path $testFilesPath "\Waiter Items\CREATE Start Job and Wait Sproc.sql"
$waiterFolderTest = Join-Path $testFilesPath "\Waiter Items\Worklist"
### global Variables

function Add-Recipe ($syncHash,$path) {
    $null = New-item -Path $path -Force -Value ""
    
    $syncHash = Update-CurrentRecipe $synchash $path
    
    if(Test-Path $path){Write-host $true}else{
    Write-Output "HI"
    Write-host $false
    }
return ,$syncHash
}
################################################
### Create a blank recipe ######################
################################################
$syncHash = Add-Recipe $synchash $BaseRecipePath
################################################
### Initialize Datagrid ######################
################################################


$baseDataGridItems = &$syncHash.Get_Recipe_Items $syncHash $BaseRecipePartPath $null $baseRecipeName $BaseRecipePartPath

$itemsSource = $baseDataGridItems.defaultview
if($itemsSource.Count -eq 0){$true}else{$false} 
################################################
### add a file to a recipe #####################
################################################
Copy-Item $baseRecipeScript $baseRecipeScriptDestination -Force
Copy-Item $baseRecipeScript2 $baseRecipeScript2Destination -Force

$baseDataGridItems = &$syncHash.Add_File $syncHash $baseRecipeScriptDestination $baseDataGridItems
$baseDataGridItems = &$syncHash.Add_File $syncHash $baseRecipeScript2Destination $baseDataGridItems
$itemsSource = $baseDataGridItems.DefaultView


if($itemsSource.Count -eq 2){$true}else{$false} 

### this teaches you can't send in the default view of a dataTable, needs to be the datatable itself.
################################################
### Save the recipe ######################
################################################
$variables = @{
    Param1   = 'whatever that is'
}


&$syncHash.Save_Recipe $synchash $baseDataGridItems $variables 

## have to strongly type it to XML, or else it won't read it properly
[XML]$BaseRecipeXML =  Get-Content $BaseRecipePath
$ingredients = $BaseRecipeXML.RecipeConfig.RecipeIngredients.Ingredient

if($ingredients.count -eq 2){$true}else{$false}

################################################
### Load the recipe ######################
################################################

$LoadedbaseDataGridItems = &$syncHash.Get_Recipe_Items $syncHash $BaseRecipePartPath $null $baseRecipeName $BaseRecipePartPath

### seems to be passing, but not sure how to make this test actually work.
if($baseDataGridItems.defaultview.count -eq $LoadedbaseDataGridItems.DefaultView.Count){$true}else{$false}
################################################
### Create a new blank Recipe ##################
################################################
$syncHash = Add-Recipe $synchash $ParentRecipePath

################################################
### add a file and the previous recipe to the new one ######################
################################################
Copy-Item $ParentRecipeScript $ParentRecipeScriptDestination -Force
Copy-Item $ParentRecipeScript2 $ParentRecipeScript2Destination -Force

$ParentRecipeDataGridItems = &$syncHash.Add_File $syncHash $ParentRecipeScriptDestination $ParentRecipeDataGridItems
$ParentRecipeDataGridItems = &$syncHash.Add_File $syncHash $ParentRecipeScript2Destination $ParentRecipeDataGridItems
$ParentRecipeDataGridItems = &$syncHash.Add_Recipe_Items $syncHash $BaseRecipePartPath $ParentRecipeDataGridItems $baseRecipeName $BaseRecipePartPath

$ParentItemsSource = $ParentRecipeDataGridItems.defaultview
if($ParentItemsSource.Count -eq 4){$true}else{
    $ParentRecipeDataGridItems | Out-GridView
    Write-Debug "HI"
    $false
} 
################################################
### Save this recipe ######################
################################################
$variables = @{
    Param1   = 'whatever that is'
}


    &$syncHash.Save_Recipe $synchash $ParentRecipeDataGridItems $variables 


## have to strongly type it to XML, or else it won't read it properly
[XML]$ParentRecipeXML =  Get-Content $ParentRecipePath
$ParentIngredients = $ParentRecipeXML.RecipeConfig.RecipeIngredients.Ingredient

if($ParentIngredients.count -eq 3){$true}else{
    $ParentRecipeDataGridItems | Out-GridView
    Start-Process notepad++ -filePath $ParentRecipePath
    Write-Debug "HI"
    $false
}
################################################
### Create a new blank Order ###################
################################################
$syncHash = Add-Recipe $synchash $OrderRecipePath

################################################
### Add the parent recipe to this one ##########
################################################
$OrderRecipeDataGridItems = &$syncHash.Add_Recipe_Items $syncHash $ParentRecipePartPath $OrderRecipeDataGridItems $parentRecipeName $ParentRecipePartPath

$OrderItemsSource = $OrderRecipeDataGridItems.defaultview

if($OrderItemsSource.Count -eq 4){$true}else{
    $OrderRecipeDataGridItems | Out-GridView
    Write-Debug "HI"
    $false
    
} 

################################################
### save the recipe ##########
################################################
$variables = @{
    Param1   = 'whatever that is'
}

&$syncHash.Save_Recipe $synchash $OrderRecipeDataGridItems $variables 

## have to strongly type it to XML, or else it won't read it properly
[XML]$OrderRecipeXML =  Get-Content $OrderRecipePath
$OrderIngredients = @()
$OrderIngredients += $OrderRecipeXML.RecipeConfig.RecipeIngredients.Ingredient

if($OrderIngredients.count -eq 1){$true}else{
    $OrderRecipeDataGridItems | Out-GridView
    $false
}
################################################
### Open the recipe ##########
################################################
### might be this right here, because I am passing in the order recipe name, it changes, before I was opening the parent recipe
$LoadedOrderDataGridItems = &$syncHash.Get_Recipe_Items $syncHash $OrderRecipePartPath $null $OrderRecipeName $OrderRecipePartPath

### seems to be passing, but not sure how to make this test actually work.
if($OrderRecipeDataGridItems.defaultview.count -eq $LoadedOrderDataGridItems.DefaultView.Count){$true}else{
    $OrderRecipeDataGridItems | Out-GridView
    $LoadedOrderDataGridItems | Out-GridView
    Write-Debug "HI"
    $false
}

################################################
### Save again ##########
################################################
$variables = @{
    Param1   = 'whatever that is'
}

&$syncHash.Save_Recipe $synchash $LoadedOrderDataGridItems $variables 

## have to strongly type it to XML, or else it won't read it properly
[XML]$OrderRecipeXML =  Get-Content $OrderRecipePath
$LoadedOrderIngredients = @()
$LoadedOrderIngredients += $OrderRecipeXML.RecipeConfig.RecipeIngredients.Ingredient

if($LoadedOrderIngredients.count -eq 1){$true}else{
    $LoadedOrderDataGridItems | Out-GridView
    $false
    Write-Debug "HI"
}
################################################
### Open again and compare that they are both the same ##########
################################################
### might be this right here, because I am passing in the order recipe name, it changes, before I was opening the parent recipe
$LoadedOrderDataGridItems = &$syncHash.Get_Recipe_Items $syncHash $OrderRecipePartPath $null $OrderRecipeName $OrderRecipePartPath

### seems to be passing, but not sure how to make this test actually work.
if($OrderRecipeDataGridItems.defaultview.count -eq $LoadedOrderDataGridItems.DefaultView.Count){$true}else{$false}
################################################
### Compare that the two configs are the same ##
################################################
if($LoadedOrderIngredients.count -eq $OrderIngredients.count){$true}else{
    $LoadedOrderDataGridItems | Out-GridView
    $OrderDataGridItems | Out-GridView
    $false
}
################################################
### Create a new blank recipe ###################
################################################
$syncHash = Add-Recipe $synchash $waiterRecipePath

################################################
### Open #######################################
################################################
$WaiterOneFileDataGridItems = &$synchash.Open_File $synchash

################################################
### Add a file using file manager  ##
################################################

$WaiterOneFileDataGridItems =  &$syncHash.File_Waiter $ParentRecipeScript $synchash $NULL
$WaiterOneFileDataGridItems =  &$syncHash.File_Waiter $ParentRecipeScript2 $synchash $WaiterOneFileDataGridItems

if($WaiterOneFileDataGridItems.defaultview.count -eq 2){$true}else{
    $WaiterOneFileDataGridItems | Out-GridView    
    $false
    Write-Debug "hi"
}
################################################
### Add a recipe using file manager  ##
################################################
$WaiterOneRecipeDataGridItems =  &$syncHash.File_Waiter $BaseRecipePath $synchash $WaiterOneFileDataGridItems

### loaded grid had 3, waiter one file added 1, then adding the order recipe adds 2 more.
if($WaiterOneRecipeDataGridItems.defaultview.count -eq $ParentRecipeDataGridItems.DefaultView.Count){$true}else{
    $WaiterOneRecipeDataGridItems | Out-GridView    
    $false
    Write-Debug "hi"
}

################################################
### Save #######################################
################################################
$variables = @{
    Param1   = 'whatever that is'
}

&$syncHash.Save_Recipe $synchash $WaiterOneRecipeDataGridItems $variables 

## have to strongly type it to XML, or else it won't read it properly
[XML]$waiterRecipeXML =  Get-Content $syncHash.CurrentRecipePath
$LoadedWaiterIngredients = @()
$LoadedWaiterIngredients += $waiterRecipeXML.RecipeConfig.RecipeIngredients.Ingredient

if($LoadedWaiterIngredients.count -eq 3){$true}else{
    $WaiterOneRecipeDataGridItems | Out-GridView
    $false
    Write-Debug "hi"
}

################################################
### Create a new blank order ##################
################################################
$syncHash = Add-Recipe $synchash $waiterorderPath

################################################
### Open #######################################
################################################
$WaiterOrderDataGridItems = &$synchash.Open_File $synchash

################################################
### Add a recipe using file manager  ##
################################################
$WaiterOrderDataGridItems =  &$syncHash.File_Waiter $ParentRecipePath $synchash $WaiterOrderDataGridItems

### loaded grid had 3, waiter one file added 1, then adding the order recipe adds 2 more.
if($WaiterOrderDataGridItems.defaultview.count -eq $ParentRecipeDataGridItems.DefaultView.Count){$true}else{
    $WaiterOrderDataGridItems | Out-GridView    
    $false
    Write-Debug "hi"
}
################################################
### Save ##########
################################################
$variables = @{
    Param1   = 'whatever that is'
}

&$syncHash.Save_Recipe $synchash $WaiterOrderDataGridItems $variables 

## have to strongly type it to XML, or else it won't read it properly
[XML]$waiterOrderRecipeXML =  Get-Content $syncHash.CurrentRecipePath
$LoadedWaiterOrderIngredients = @()
$LoadedWaiterOrderIngredients += $waiterOrderRecipeXML.RecipeConfig.RecipeIngredients.Ingredient

if($LoadedWaiterOrderIngredients.count -eq 1){$true}else{
    $WaiterOrderDataGridItems | Out-GridView
    $false
    Write-Debug "hi"
}

################################################
### Open #######################################
################################################
$WaiterLoadedOrderDataGridItems = &$synchash.Open_File $synchash

if($WaiterLoadedOrderDataGridItems.defaultview.count -eq 4){$true}else{
    $false 
    Write-Debug "HI"
    $WaiterLoadedOrderDataGridItems | Out-GridView
}
################################################
### Create a new blank recipe ##################
################################################
$syncHash = Add-Recipe $synchash $waiterFolderRecipePath


################################################
### Add a folder without a recipe file manager##
################################################
$WaiterDataGridItems =  &$syncHash.File_Waiter $waiterFolderTest $synchash $null

### loaded grid had 3, waiter one file added 1, then adding the order recipe adds 2 more.
if($WaiterDataGridItems.defaultview.count -eq 2){$true}else{
    $WaiterDataGridItems | Out-GridView    
    $false
    Write-Debug "hi"
}
#Write-Output "hi"
################################################
### Add a folder with a recipe file manager  ###
################################################
$WaiterDataGridItems =  &$syncHash.File_Waiter $waiterRecipeFolder $synchash $WaiterDataGridItems

### loaded grid had 3, waiter one file added 1, then adding the order recipe adds 2 more.
if($WaiterDataGridItems.defaultview.count -eq 10){$true}else{
    $WaiterDataGridItems | Out-GridView    
    $false
    Write-Debug "hi"
}

################################################
### Save ##########
################################################
$variables = @{
    Param1   = 'whatever that is'
}

&$syncHash.Save_Recipe $synchash $WaiterDataGridItems $variables 

## have to strongly type it to XML, or else it won't read it properly
[XML]$waiterFolderRecipeXML =  Get-Content $syncHash.CurrentRecipePath
$LoadedWaiterFolderIngredients = @()
$LoadedWaiterFolderIngredients += $waiterFolderRecipeXML.RecipeConfig.RecipeIngredients.Ingredient

if($LoadedWaiterFolderIngredients.count -eq 4){$true}else{
    $WaiterDataGridItems | Out-GridView
    $false
    Write-Debug "hi"
}

################################################
### Remove  ###
################################################
$rowsToremove = @()
foreach($row in $WaiterDataGridItems){
    if($RowsToRemove.Count -lt 4){
        $RowsToRemove += $row
    }
}
[System.Data.DataTable]$typeTest = $WaiterDataGridItems

foreach($row in $rowsToremove){
    $WaiterDataGridItems.rows.remove($row)
}

######
$i = 1
foreach($row in $waiterDatagridItems){
    $row.RunOrder = $i
    $i++
}

######


$i = 1
$Errored = 0
foreach($row in $WaiterDataGridItems){
    if($row.RunOrder -ne $i){
    $error = 1
    }
    $i++
}
if($Errored -eq 1){
$false
}else{$true}

Write-debug "HI"
#####################################################
# remove-variable baseDataGridItems
# remove-variable itemssource
# remove-variable synchash
# remove-variable ParentRecipeDataGridItems
# Remove-Variable OrderRecipeDataGridItems
# remove-variable WaiterOneFileDataGridItems
# Remove-Variable WaiterOneRecipeDataGridItems
# Remove-Variable WaiterDataGridItems
# Remove-Variable WaiterOrderDataGridItems
# Remove-Variable WaiterLoadedOrderDataGridItems